import 'package:flutter/material.dart';

import 'UI/MyApp.dart';


void main() => runApp(MyApp());


void Main() => runApp(MyApp());

