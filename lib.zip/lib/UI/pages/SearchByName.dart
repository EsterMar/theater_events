import 'package:theater_events/UI/behaviors/AppLocalizations.dart';
import 'package:theater_events/model/Model.dart';
import 'package:theater_events/model/support/extensions/StringCapitalization.dart';
import 'package:flutter/material.dart';

import '../../model/objects/Spettacolo.dart';
import '../widget/CircularIconButton.dart';
import '../widget/InputField.dart';
import '../widget/ShowCard.dart';


class SearchByName extends StatefulWidget {
  const SearchByName({Key? key}) : super(key: key);


  @override
  _SearchState createState() => _SearchState();
}

class _SearchState extends State<SearchByName> {
  bool _searching = false;
  List<Spettacolo>? _products;

  TextEditingController _searchFiledController = TextEditingController();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          children: [
            top(),
            bottom(),
          ],
        ),
      ),
    );
  }

  Widget top() {
    return Padding(
      padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
      child: Row(
        children: [
          Flexible(
            child: InputField(
              labelText: AppLocalizations.of(context).translate("search").capitalize,
              controller: _searchFiledController,
              onSubmit: (value) {
                _search();
              }, initialValue: '',
            ),
          ),
          CircularIconButton(
            icon: Icons.search_rounded,
            onPressed: () {
              _search();
            }, padding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }

  Widget bottom() {
    return  !_searching ?
    _products == null ?
    SizedBox.shrink() :
    _products?.length == 0 ?
    noResults() :
    yesResults() :
    CircularProgressIndicator();

  }

  Widget noResults() {
    return Text(AppLocalizations.of(context).translate("no_results").capitalize + "!");
  }

  Widget yesResults() {
    return Expanded(
      child: Container(
        child: ListView.builder(
          itemCount: _products?.length,
          itemBuilder: (context, index) {
            return ShowCard(
              product: _products![index],
            );
          },
        ),
      ),
    );
  }

  void _search() {
    setState(() {
      _searching = true;
      _products = null;
    });
    Model.sharedInstance.searchShow(_searchFiledController.text).then((result) {
      setState(() {
        _searching = false;
        _products = result;
      });
    });
  }
}
