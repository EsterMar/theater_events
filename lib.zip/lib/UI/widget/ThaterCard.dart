import 'package:theater_events/model/objects/Teatro.dart';
import 'package:flutter/material.dart';


class TheaterCard extends StatelessWidget {
  final Teatro? theater;


  TheaterCard({Key? key, this.theater}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20.0),
      ),
      child: Padding(
        padding: EdgeInsets.all(10),
        child: Column(
          children: [
            Text(
              theater!.name!,
              style: TextStyle(
                fontSize: 40,
                color: Theme.of(context).primaryColor
              ),
            ),
            Text(
              theater!.city!,
              style: TextStyle(
                color: Theme.of(context).primaryColor,
              ),
            ),
            Text(
              theater!.address!,
              style: TextStyle(
                color: Theme.of(context).primaryColor,
              ),
            ),
            Text(
              theater!.telephone_number!,
              style: TextStyle(
                color: Theme.of(context).primaryColor,
              ),
            ),
          ],
        ),
      ),
    );
  }


}
