abstract class ErrorListener {


  void errorNetworkOccurred(String message);
  void errorNetworkGone();


}